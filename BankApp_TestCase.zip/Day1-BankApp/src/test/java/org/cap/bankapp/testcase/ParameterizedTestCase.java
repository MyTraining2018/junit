package org.cap.bankapp.testcase;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTestCase {

	private AcccountService acccountService=new AccountServiceImpl();
	
	private Integer input1;
	private Integer input2;
	private Integer output;
	
	public ParameterizedTestCase(Integer input1, Integer input2, Integer output) {
		super();
		this.input1 = input1;
		this.input2 = input2;
		this.output = output;
	}
	
	
	@Parameters
	public static List<Object[]> getAllParameters(){
		return Arrays.asList(new Object[][] {
			{1,2,3},
			{0,5,5},
			{-90,-10,-100},
			{0,-67,-67}
		});
	}
	
	
	
	@Test
	public void test_AddNumbers() {
		assertEquals(output.intValue(), acccountService.addNumbers(input1, input2));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
