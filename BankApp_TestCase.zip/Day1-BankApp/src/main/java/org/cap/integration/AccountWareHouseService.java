package org.cap.integration;

import org.cap.dto.AccountMessage;

public class AccountWareHouseService {
	
	public static boolean sendAccount(AccountMessage accountMessage) throws WareHoseNotAvailableException {
		throw new WareHoseNotAvailableException();
	}

}
