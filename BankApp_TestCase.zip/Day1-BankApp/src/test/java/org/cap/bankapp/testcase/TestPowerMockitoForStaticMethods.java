package org.cap.bankapp.testcase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.cap.dao.AccountDao;
import org.cap.dto.Account;
import org.cap.dto.AccountMessage;
import org.cap.dto.Customer;
import org.cap.integration.AccountWareHouseService;
import org.cap.integration.WareHoseNotAvailableException;
import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value= {AccountServiceImpl.class,AccountWareHouseService.class})
public class TestPowerMockitoForStaticMethods {
	
	private AcccountService accountService;
	
	@Mock
	private AccountDao accountDao;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	@Test
	public void test_transferAccount_withPowerMockito() throws WareHoseNotAvailableException {
		 
		List<Account> accounts=new ArrayList<>();
		accounts.add(new Account(1, new Customer(), 2300));
		accounts.add(new Account(1231, new Customer(), 67000));
		accounts.add(new Account(100, new Customer(), 4500));
		
		
		
		//Dummy Declaration
		Mockito.when(accountDao.getAllAccounts(new Date(2000, 11, 23))).thenReturn(accounts);
		
		PowerMockito.mockStatic(AccountWareHouseService.class);
		PowerMockito.when
			(AccountWareHouseService.sendAccount(Matchers.any(AccountMessage.class)))
			.thenReturn(true);
		
		
		//Actual Logic
		accountService.transferAccount(new Date(2000, 11, 23));
		
		
		//Verifiation
		Mockito.verify(accountDao).getAllAccounts(new Date(2000, 11, 23));
		PowerMockito.verifyStatic();
		
		
		
		
		
	}

}
