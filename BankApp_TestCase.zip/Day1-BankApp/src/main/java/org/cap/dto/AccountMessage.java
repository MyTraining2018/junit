package org.cap.dto;

import java.util.List;

public class AccountMessage {
	
	private int accountMessageId;
	private String accountMessage;
	private List<Account> accounts;
	public AccountMessage() {
		
	}
	
	
	public AccountMessage(int accountMessageId, String accountMessage, List<Account> accounts) {
		super();
		this.accountMessageId = accountMessageId;
		this.accountMessage = accountMessage;
		this.accounts = accounts;
	}
	public int getAccountMessageId() {
		return accountMessageId;
	}
	public void setAccountMessageId(int accountMessageId) {
		this.accountMessageId = accountMessageId;
	}
	public String getAccountMessage() {
		return accountMessage;
	}
	public void setAccountMessage(String accountMessage) {
		this.accountMessage = accountMessage;
	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	@Override
	public String toString() {
		return "AccountMessage [accountMessageId=" + accountMessageId + ", accountMessage=" + accountMessage
				+ ", accounts=" + accounts + "]";
	}
	
	

}
