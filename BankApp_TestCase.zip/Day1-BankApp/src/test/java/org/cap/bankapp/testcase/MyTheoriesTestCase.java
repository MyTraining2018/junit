package org.cap.bankapp.testcase;

import static org.junit.Assert.assertTrue;

import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Assume;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;


@RunWith(Theories.class)
public class MyTheoriesTestCase {
	
	private AcccountService accountService =new AccountServiceImpl();
	

	
	@DataPoints
	public static int[] myDataSet() {
		return new int[] {
			1,0,-1,-23,90,23,-12	
		};
	}
	
	
	
	
	@Theory
	public void testMystatements(int x,int y) {
		
		System.out.println(x + "---->" + y);
		
		Assume.assumeTrue(x>0 && y>0);
		
		assertTrue(x+y>0);
	}
	
	@Theory
	public void testCommutativeLaw(int x,int y) {
		
		Assume.assumeTrue(x>0 && y>0);
		
	
		
		//assertTrue(x+y == y+x);
		
		assertTrue(	accountService.addNumbers(x, y)>0);
	}
	
}











