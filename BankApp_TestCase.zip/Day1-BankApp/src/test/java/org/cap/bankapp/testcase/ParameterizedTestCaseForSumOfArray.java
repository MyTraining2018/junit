package org.cap.bankapp.testcase;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTestCaseForSumOfArray {
	
	private AcccountService acccountService=new AccountServiceImpl();

	private Integer[] input;
	private Integer output;
	
	
	public ParameterizedTestCaseForSumOfArray(Integer[] input, Integer output) {
		super();
		this.input = input;
		this.output = output;
	}
	
	@Parameters
	public static List<Object[]> myParams(){
		return Arrays.asList(new Object[][] {
			{new Integer[]{1,2,3},6},
			{new Integer[]{11,0,3},14},
			{new Integer[]{-1,0,3},2}
			
		});
	}
	
	@Test
	public void test_sumOfArray() {
		assertEquals(output.intValue(), acccountService.sunOfArray(input));
	}
	
	
}
