package org.cap.bankapp.testcase;

import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;

public class ConsoleRunner {

	public static void main(String[] args) {
		JUnitCore unitCore=new JUnitCore();
		
		unitCore.addListener(new TextListener(System.out));
		
		unitCore.run(BankAppTestCase.class);
		unitCore.run(AppSuiteTest.class);
		unitCore.run(ParameterizedTestCaseForSumOfArray.class);

	}

}
