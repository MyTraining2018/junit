package org.cap.bankapp.testcase;

import static org.mockito.Matchers.contains;

import org.cap.dto.Customer;
import org.cap.exception.InvalidInitialAmountException;
import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.Timeout;

public class TestCasewithRules {
	
	private AcccountService accountService=new AccountServiceImpl();
	
	
	
	@Rule
	public ExpectedException thrown=ExpectedException.none();
	
	
	@Test
	public void test_customer_with_null_when_addAccount() throws InvalidInitialAmountException {
		
		Customer customer=null;
		thrown.expect(IllegalArgumentException.class);
		//thrown.expectMessage("Sorry! Null customer could not be added!");
		thrown.expectMessage(contains("customer"));
		accountService.addAccount(customer, 45000);
		
	}
	
	
	@Rule
	public Timeout timeout=Timeout.millis(100);
	@Test
	public void test_CheckLoop() {
		
		accountService.checkLoop();
	}

}
