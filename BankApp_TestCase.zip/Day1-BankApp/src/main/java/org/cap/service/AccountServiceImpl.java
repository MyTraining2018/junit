package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.dao.AccountDao;
import org.cap.dto.Account;
import org.cap.dto.AccountMessage;
import org.cap.dto.Customer;
import org.cap.exception.InsufficientBalanceException;
import org.cap.exception.InvalidInitialAmountException;
import org.cap.integration.AccountWareHouseService;
import org.cap.integration.WareHoseNotAvailableException;
import org.cap.util.AccountUtil;

public class AccountServiceImpl implements AcccountService{
	
	private AccountDao accountDao;
	
	
	public AccountServiceImpl(){}

	public AccountServiceImpl(AccountDao accountDao) {
		super();
		this.accountDao = accountDao;
	}

	@Override
	public Account addAccount(Customer customer, double amount) throws InvalidInitialAmountException {
		
		if(customer==null)
			throw new IllegalArgumentException("Sorry! Null customer could not be added!");
		if(amount<500)
			throw new InvalidInitialAmountException();
		
		Account account=new Account();
		account.setAccountNo(AccountUtil.generateAccountNumber());
		account.setCustomer(customer);
		account.setAmount(amount);
		
		//Dao dependency
		if(accountDao.createAccount(account))
			return account;
		
		return null;
	}

	@Override
	public Account findAccountById(int accountNo) {
		
		return accountDao.findAccountById(accountNo);
	}

	@Override
	public Account withdraw(int accountNo, double amount) throws InsufficientBalanceException {
		
		Account account=accountDao.findAccountById(accountNo);
		
		if(account.getAmount()<amount)
			throw new InsufficientBalanceException();
		
		account.setAmount(account.getAmount()-amount);
		
		
		return account;
	}

	@Override
	public Account deposit(int accountNo, double amount) {
		Account account=accountDao.findAccountById(accountNo);
		
		account.setAmount(account.getAmount()+amount);
		
		return account;
	}
	
	
	
	@Override
	public int addNumbers(int num1,int num2){
		return num1+num2;
	}

	@Override
	public void checkLoop() {
		long sum=0;
		for(long i=0;i<60000;i++) {
			sum+=i;
		}
		
	}

	@Override
	public int sunOfArray(Integer... args) {
		int sum=0;
		for(int num:args)
			sum+=num;
		return sum;
	}

	@Override
	public void transferAccount(Date date) throws WareHoseNotAvailableException {
		
	List<Account> accounts= accountDao.getAllAccounts(date);
	
	AccountMessage accountMessage=new AccountMessage();
	accountMessage.setAccountMessageId(AccountUtil.generateAccountNumber());
	accountMessage.setAccountMessage("Accounts Added" + new Date());
	accountMessage.setAccounts(accounts);
	
	
	AccountWareHouseService.sendAccount(accountMessage);
		
	}
	
	
	
	
	
	
	
	
	

}
