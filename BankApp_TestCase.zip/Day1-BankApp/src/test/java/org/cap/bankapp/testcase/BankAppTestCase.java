package org.cap.bankapp.testcase;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import org.cap.dao.AccountDao;
import org.cap.dto.Account;
import org.cap.dto.Address;
import org.cap.dto.Customer;
import org.cap.exception.InsufficientBalanceException;
import org.cap.exception.InvalidInitialAmountException;
import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class BankAppTestCase {
	
	private AcccountService accountService;
	
	@Mock
	private AccountDao accountDao;
	
	@BeforeClass
	public static void beforeClass_Method() {
		//System.out.println("Before - Class");
	}
	
	
	@AfterClass
	public static void afterClass_Method() {
		//System.out.println("After - Class");
	}
	
	@Before
	public void setUp() {
		//System.out.println("Before - SetUp");
		
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	
	@After
	public void tearDown() {
		//System.out.println("After - TearDown - CleanUp");
		accountService=null;
		
	}
	
	
	
	//@Category({GoodTestCategory.class,BadTestCategory.class})
	@Category(GoodTestCategory.class)
	@Test(expected=IllegalArgumentException.class)
	public void test_customer_with_null_when_addAccount() throws InvalidInitialAmountException{
		//accountService=new AccountServiceImpl();
		//System.out.println("test_customer_with_null_when_addAccount()");
		Customer customer=null;
		accountService.addAccount(customer, 200);
		
		
	}

	
	@Category(BadTestCategory.class)
	@Test(expected=InvalidInitialAmountException.class)
	public void test_InsufficientBanlace_when_addAccount() throws InvalidInitialAmountException{
		//accountService=new AccountServiceImpl();
		
		Customer customer=new Customer();
		customer.setCustName("Tom");
		Address address=new Address();
		address.setAddressLine("North Avvenue");
		
		//try {
			accountService.addAccount(customer, 200);
		/*} catch (InvalidInitialAmountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}*/
		
	}
	
	@Ignore
	@Category(GoodTestCategory.class)
	@Test(timeout=100)
	public void test_CheckLoop() {
		accountService.checkLoop();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Test
	public void test_addAccount_with_mockito_verify() throws InvalidInitialAmountException {
		
		Account account=new Account();
		Customer customer=new Customer();
		customer.setCustName("Jack");
		
		Address address=new Address();
		address.setAddressLine("North Avvenue");
		customer.setCustAddress(address);
		
		//account.setAccountNo(0);
		account.setCustomer(customer);
		account.setAmount(2300);
		
		//Dummy Declaration
		Mockito.when(accountDao.createAccount(account)).thenReturn(true);
		
		//Actual Logic
		Account newAccount=accountService.addAccount(customer, 2300);
		
		//Mockito Verification
		Mockito.verify(accountDao).createAccount(account);
		
		assertNotNull(newAccount);
		assertEquals(newAccount.getAmount(), account.getAmount(),0.0);
		
		
		
	}
	
	
	
	@Test
	public void test_findByAccountId_method_with_mockito() {
		
		Account account=new Account();
		Customer customer=new Customer();
		customer.setCustName("Jack");
		
		Address address=new Address();
		address.setAddressLine("North Avvenue");
		customer.setCustAddress(address);
		
		account.setAccountNo(1003);
		account.setCustomer(customer);
		account.setAmount(2300);
		
		
		
		
		//Dummy Declaration
		Mockito.when(accountDao.findAccountById(1003)).thenReturn(account);
		
		//Actutal Logic
		Account found=accountService.findAccountById(1003);
		
		//Verification
		Mockito.verify(accountDao).findAccountById(1003);
	}
	
	
	
	@Test
	public void test_widthdraw_method_with_mockito() throws InsufficientBalanceException {
		
		Account account=new Account();
		Customer customer=new Customer();
		customer.setCustName("Jack");
		
		Address address=new Address();
		address.setAddressLine("North Avvenue");
		customer.setCustAddress(address);
		
		account.setAccountNo(1003);
		account.setCustomer(customer);
		account.setAmount(2300);
		
		
		
		
		//Dummy Declaration
		Mockito.when(accountDao.findAccountById(1003)).thenReturn(account);
		
		//Actutal Logic
		Account found=accountService.withdraw(1003, 1000);
		
		//Verification
		Mockito.verify(accountDao).findAccountById(1003);
		
		
		assertEquals(1300, found.getAmount(),0.0);
	}
	
	
	
	
	
	@Test
	public void test_deposit_method_with_mockito() throws InsufficientBalanceException {
		
		Account account=new Account();
		Customer customer=new Customer();
		customer.setCustName("Jack");
		
		Address address=new Address();
		address.setAddressLine("North Avvenue");
		customer.setCustAddress(address);
		
		account.setAccountNo(1003);
		account.setCustomer(customer);
		account.setAmount(2300);
		
		
		
		
		//Dummy Declaration
		Mockito.when(accountDao.findAccountById(1003)).thenReturn(account);
		
		//Actutal Logic
		Account found=accountService.deposit(1003, 1000);
		
		//Verification
		Mockito.verify(accountDao).findAccountById(1003);
		
		
		assertEquals(3300, found.getAmount(),0.0);
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
