package org.cap.bankapp.testcase;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ BankAppTestCase.class, TestCaseApp.class })
public class AppSuiteTest {

}
