package org.cap.dao;

import java.util.Date;
import java.util.List;

import org.cap.dto.Account;
import org.cap.dto.Customer;

public class AccountDaoImpl implements AccountDao{

	@Override
	public boolean createAccount(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findAccountById(int accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAllAccounts(Date date) {
		// TODO Auto-generated method stub
		return null;
	}

}
