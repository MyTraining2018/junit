package org.cap.integration;

public class WareHoseNotAvailableException extends Exception {

}
