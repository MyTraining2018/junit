package org.cap.bankapp.testcase;

public interface GoodTestCategory {

}
