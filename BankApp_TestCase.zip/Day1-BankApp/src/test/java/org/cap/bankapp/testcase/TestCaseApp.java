package org.cap.bankapp.testcase;

import static org.junit.Assert.*;

import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Test;
import org.junit.experimental.categories.Category;

public class TestCaseApp {

	private AcccountService accountService;
	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	
	
	@Category(GoodTestCategory.class)
	@Test
	public void test_Addnumbers() {
		accountService=new AccountServiceImpl();
		
		assertEquals(50, accountService.addNumbers(10, 40));
	}

}
