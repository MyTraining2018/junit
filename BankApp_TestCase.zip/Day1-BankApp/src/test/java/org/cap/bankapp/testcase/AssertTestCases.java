package org.cap.bankapp.testcase;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.cap.service.AcccountService;
import org.cap.service.AccountServiceImpl;
import org.junit.Before;
import org.junit.Test;

public class AssertTestCases {
	
	private AcccountService accountService;
	
	@Before
	public void setUp() {
		accountService=new AccountServiceImpl();
	}
	
	@Test
	public void addNumber_Test() {
		
		assertEquals(50, accountService.addNumbers(20, 30));
		
		assertThat(accountService.addNumbers(20, 30), is(50));
		
		assertThat(accountService.addNumbers(20, 30), allOf(is(50),
				instanceOf(Integer.class)));
		
		assertTrue(accountService.addNumbers(10, 30)>0);
		
	}

}
